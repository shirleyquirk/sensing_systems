#ifndef LOGGING_H
#define LOGGING_H

/*****LOGGING**********/
#define LOG_NONE 0
#define LOG_INFO 1
#define LOG_DEBUG 2
#define LOG_SHITFIGHT 3

//#define LOGLEVEL LOG_NONE
#define LOGLEVEL LOG_INFO
//#define LOGLEVEL LOG_DEBUG
//#define LOGLEVEL LOG_SHITFIGHT

#define log_println(loglevel,...)\
    do {if (LOGLEVEL>=loglevel) Serial.println(__VA_ARGS__);}while(0)
#define log_print(loglevel,...)\
    do {if (LOGLEVEL>=loglevel) Serial.print(__VA_ARGS__);}while(0)
/***********************/
#endif
/*LOGGING_H*/
